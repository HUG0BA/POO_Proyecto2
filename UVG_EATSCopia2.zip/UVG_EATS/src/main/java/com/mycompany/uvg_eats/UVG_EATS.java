/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.uvg_eats;
import clases.*;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author Fercho
 */
public class UVG_EATS {
    static Scanner scanner = new Scanner(System.in);
    
    
    public static void main(String[] args) {
        
        
        Menu_Usuario menuUsario = new Menu_Usuario();
        menuUsario.setVisible(true);
    }
}
